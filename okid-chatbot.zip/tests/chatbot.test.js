import { expect } from 'chai';

describe('Chatbot', () => {
  it('should pass a basic test', () => {
    expect(1 + 1).to.equal(2);
  });
});
